from django.urls import path
from .views import index, agregar_vehiculo, listar_vehiculos 

urlpatterns = [
    path('', index, name='index'),
    path('vehiculo/add/', agregar_vehiculo, name='agregar_vehiculo'),
    path('vehiculo/list/', listar_vehiculos, name='listar_vehiculos'),
]
